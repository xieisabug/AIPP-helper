---
doc_type: scene_optimizer_operation
operation: rtxMeshCount
title: RTX Mesh Count
source: scene-optimizer-core/source/operations/rtxMeshCount/RtxMeshCount.cpp
category: analysis
loss_class: analysis-only
requires_confirmation: false
risk_class: low
args_count: 1
requires_mesh: true
pipelines: []
keywords: [rtx, mesh-count, raytracing, stats]
since_version: 2026-02-11T07:51:19Z
requires_extension: omni.scene.optimizer.core
---
<!-- SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved. -->
<!-- SPDX-License-Identifier: Apache-2.0 -->

# RTX Mesh Count

This local file is a routing stub only. Its YAML frontmatter is the local
catalog source for operation selection, risk, confirmation, and workflow
metadata.

For Scene Optimizer operation mechanics, parameters, defaults, and implementation
notes, use [Operation Index](README.md) and the centralized [`usd-optimize`
upstream handoff](../upstreams/usd-optimize.md). Resolve the package operation
guide by the `operation` key in this file; do not restate upstream mechanics
here.
